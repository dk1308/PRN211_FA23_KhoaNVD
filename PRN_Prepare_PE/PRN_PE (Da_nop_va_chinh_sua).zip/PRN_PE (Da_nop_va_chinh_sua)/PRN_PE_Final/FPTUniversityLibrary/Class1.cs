﻿namespace FPTUniversityLibrary
{
    public class Class1
    {

    }
}