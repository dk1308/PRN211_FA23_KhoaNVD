﻿namespace EStoreWeb.Models
{
    public class Admin
    {
        public String Email { get; set; }
        public String Password { get; set; }
    }
}

