﻿namespace Object
{
    public class Class1
    {

    }
}